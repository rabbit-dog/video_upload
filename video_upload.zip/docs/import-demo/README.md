## desc

This demo show how to install `vod-js-sdk-v6` by npm and use it in a webpack environment.

## demo url

https://tencentyun.github.io/vod-js-sdk-v6/import-demo/index.html

## How to build

1. run `npm install` in this directory
2. run `npx webpack --entry ./main.js --output ./bundle.js` to build bundle.js
3. launch a http server in this directory, and open `index.html`