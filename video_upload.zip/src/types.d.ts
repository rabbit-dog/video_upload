export type vodError = Error & {
  code?: number;
};
